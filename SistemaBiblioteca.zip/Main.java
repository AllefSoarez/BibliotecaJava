import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();
        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("\n--- Sistema de Gerenciamento de Biblioteca ---");
            System.out.println("1. Adicionar Livro");
            System.out.println("2. Adicionar Revista");
            System.out.println("3. Listar Materiais");
            System.out.println("4. Pesquisar Material por Título");
            System.out.println("5. Excluir Material por Título");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine(); // limpar buffer

            switch (opcao) {
                case 1:
                    System.out.print("Título do livro: ");
                    String tituloLivro = scanner.nextLine();
                    System.out.print("Autor do livro: ");
                    String autorLivro = scanner.nextLine();
                    System.out.print("Gênero (FICCAO, NAO_FICCAO, CIENCIA, HISTORIA, BIOGRAFIA, FANTASIA): ");
                    String generoStr = scanner.nextLine();

                    if (tituloLivro.isEmpty() || autorLivro.isEmpty() || generoStr.isEmpty()) {
                        System.out.println("Por favor, preencha todos os campos obrigatórios.");
                        break;
                    }

                    try {
                        Genero genero = Genero.valueOf(generoStr.toUpperCase());
                        Livro livro = new Livro(tituloLivro, autorLivro, genero);
                        biblioteca.adicionarMaterial(livro);
                    } catch (IllegalArgumentException e) {
                        System.out.println("Gênero inválido.");
                    }
                    break;

                case 2:
                    System.out.print("Título da revista: ");
                    String tituloRevista = scanner.nextLine();
                    System.out.print("Autor da revista: ");
                    String autorRevista = scanner.nextLine();
                    System.out.print("Número da revista: ");
                    String numeroStr = scanner.nextLine();

                    if (tituloRevista.isEmpty() || autorRevista.isEmpty() || numeroStr.isEmpty()) {
                        System.out.println("Por favor, preencha todos os campos obrigatórios.");
                        break;
                    }

                    try {
                        int numero = Integer.parseInt(numeroStr);
                        Revista revista = new Revista(tituloRevista, autorRevista, numero);
                        biblioteca.adicionarMaterial(revista);
                    } catch (NumberFormatException e) {
                        System.out.println("Número inválido.");
                    }
                    break;

                case 3:
                    biblioteca.listarMateriais();
                    break;

                case 4:
                    System.out.print("Digite o título do material: ");
                    String tituloBusca = scanner.nextLine();
                    Material encontrado = biblioteca.pesquisarPorTitulo(tituloBusca);
                    if (encontrado != null) {
                        System.out.println("Material encontrado: " + encontrado);
                    } else {
                        System.out.println("Material não encontrado.");
                    }
                    break;

                case 5:
                    System.out.print("Digite o título do material para excluir: ");
                    String tituloExclusao = scanner.nextLine();
                    biblioteca.excluirMaterial(tituloExclusao);
                    break;

                case 0:
                    System.out.println("Encerrando o sistema...");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }
        } while (opcao != 0);

        scanner.close();
    }
}